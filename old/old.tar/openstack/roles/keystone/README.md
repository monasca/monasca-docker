#Keystone

A simple installation of keystone, using the system packages and default config leveraging sqlite for the db.
The only thing done besides the default config is setting the admin token.

##Role Variables
`keystone_admin_token` must be defined
