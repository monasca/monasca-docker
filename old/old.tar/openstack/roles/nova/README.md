#Nova
A simple installation of nova, using the system packages and default config.
