#Horizon
A simple installation of horizon, using the system packages and default config.

##Role Variables
`keystone_url` must be defined
