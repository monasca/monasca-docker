#Glance
A simple installation of glance, using the system packages and default config.
