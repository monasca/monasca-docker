#Cinder
A simple installation of cinder, using the system packages and default config.
