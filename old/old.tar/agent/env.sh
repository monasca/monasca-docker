# Environment variables for use with python-monascaclient running via monaca-vagrant

export OS_USERNAME=mini-mon
export OS_PASSWORD=password
export OS_PROJECT_NAME=mini-mon
export OS_AUTH_URL=http://keystone:35357/v3/
